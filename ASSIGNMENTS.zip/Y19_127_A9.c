#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>

	// Problem 1
/*int addpridig(long long int num, int sum)
{
	if(num>0)	
	{if(num%10==2 || num%10==3 || num%10==5 || num%10==7)
	    sum=sum+num%10;
	   return addpridig(num/10,sum);
	}
	return sum;
}
int main()
	{ long long int n;
	  printf("Enter a Number n = ");
	  scanf("%lld",&n);
	  printf("Sum of prime digits in %lld is %d\n",n,addpridig(n,0));
	}*/

  	// Problem 2
/*int primenum(int n)
{	int a=n,flag;
	if(a>0)
	 { while(a>0) 
		{ if((a%10==1 || (a%10)%3==0) && a%10!=0)
		  {flag=0;
		   a=a/10;}
		 else
		  {flag=1;
		   break;}
		}
	   if(flag==0) 
	   printf("%d ",n);
	   return primenum(n-1);
	 }
	
}
int main()
{	int x;
	printf("Enter a Number x = ");
	scanf("%d",&x);
	primenum(x-1);
	printf("\n");
}*/

	// Problem 3
/*int count = 0,repeat[30],initial = 0;
int max = 0,maxchar = 0;
int get_max(int k, char str[], int initial) {
//char str[30] = {'a','c','b','a','a','c','d','e','c','e','e','f','d','a','c','a','d','e','c','a','e','f','e','f','a','f','e','c','e','f'};

	int i, flag;
	repeat[initial] = 0;
	count += 1;

	if(count <= 32 - k) { //return maxchar;
	for(int j = initial; j <= 30 - k; j++) {
		flag = 0,i = 1;
		if(str[initial] == str[j + k]) {

			for(i = 1; i <= k - 1; i++) {
				if(str[initial + i] == str[j + k + i]) {
					flag += 1;

				}
			}			
			if(flag == i) repeat[initial] += 1;
			
		}
	}
	
if(max < repeat[initial]) {
	max = repeat[initial];
	maxchar = initial;
} 
printf("str[%d] : %c\t",initial,str[initial]);
//printf("initial : %d\t",initial);

//printf("%d\t",maxchar);
get_max(k, str,initial + 1);
}
return maxchar;
}

int main() {
	
int k,startstring = 0;
char str[30] = {'a','c','b','a','a','c','d','e','c','e','e','f','d','a','c','a','d','e','c','a','e','f','e','f','a','f','e','c','e','f'};

	printf("Enter The Length of Sub String : ");
	scanf("%d",&k);

startstring = get_max(k, str, 0);
	printf("\n");

	for(int i = 0; i < k; i++) 
      {
         printf("%c",str[startstring + i]);
	//printf("%c",str[get_max(k, str, 0) + i]);
      }
	printf("\n");
return 0;
}*/

	// Problem 4
/*int min = 100,max = 0;
int smallesteven(int arr[],int n, int k) 
	{
	 if(k == n) return min;
		if(min > arr[k]) 
			if(arr[k] % 2 == 0) min = arr[k];

	  smallesteven(arr, n, k+1);
	}

int largestodd(int arr[],int n, int k) 
	{
	 if(k == n) return max;
       	   if(min < arr[k]) 
	  	 if(arr[k] % 2 != 0) max = arr[k];

	  largestodd(arr, n, k+1);
	}

int main() {
int n;
srand(time(0));

printf("Enter The Value of N : ");
scanf("%d",&n);
int arr[n];
for(int i = 0; i < n; i++) {
	arr[i] = (unsigned int)rand() % 20 + 1;
}

printf("\nThe Numbers Are : ");

for(int i = 0; i < n; i++) {
	printf("\t%2.d",arr[i]);
}

printf("\n");

printf("\nThe smallest Even Number is : %d\n",smallesteven(arr, n,0));
printf("\nThe Largest Odd Number is : %d\n",largestodd(arr, n, 0));
return 0;

}*/

	// Problem 5
/*int fifthRecForK2(int n, int i,int ar[])
{
    if(n==i-1)
        return 0;
    //printf("\n\n%d, %d are the elements \n",ar[i],ar[i+1]);
    for(int j=0;j<n-1;j++)
    {
        //printf("%d and %d are the j and j+1th elements \n",ar[j],ar[j+1]);
        if(ar[j]%ar[i]==0 && ar[j+1]%ar[i+1]==0 && i!=j && ar[j]/ar[i]==ar[j+1]/ar[i+1])
        printf("%d at %d, %d at %d multiplied by %d is the same as %d at %d, %d at %d \n",ar[i],i,ar[i+1],i+1,ar[j]/ar[i],ar[j],j,ar[j+1],j+1);
    }
    fifthRecForK2(n,i+1,ar);
}

int k3fifthrec(int n, int i,int ar[])
{
    if(n==i-2)
        return 0;
    for(int j=0;j<n-2;j++)
    {
        if(ar[j]%ar[i]==0 && ar[j+1]%ar[i+1]==0 && ar[j+2]%ar[i+2]==0 && i!=j && ar[j]/ar[i]==ar[j+1]/ar[i+1] && ar[j+2]/ar[i+2]==ar[j+1]/ar[i+1])
            printf("%d at %d, %d at %d, %d ar %d multiplied by %d is the same as %d at %d, %d at %d,%d at %d \n",ar[i],i,ar[i+1],i+1,ar[i+2],i+2,ar[j]/ar[i],ar[j],j,ar[j+1],j+1,ar[j+2],j+2);
    }
    k3fifthrec(n,i+1,ar);
}


int main() {
 int ar[] = {2, 3, 7,5, 1, 2, 7, 4, 4, 2, 6, 9, 21,10, 2, 4, 4, 2, 6, 9};
    printf("K = 2\n");
    fifthRecForK2(20,0,ar);
    printf("K = 3\n");
    k3fifthrec(20,0,ar);
    return 0;

}*/
	// Problem 6
/*int sixrecur(int n, int i, int ar[], int newarr[][20],int nprime, int prime)
{
    if(n==i)
        return prime;
    int x=ar[i];
    int f = 0;
    if(x%2==0 && x!=2)
    {
        f = 1;
        newarr[1][nprime] = x;//nprime keeps a count of the index of the non-prime numbers
        nprime++;
    }
    else{
        for(int i = 3;i<sqrt(x);i+=2)
        {
            if(x%i==0)
            {
                f = 1;
                newarr[1][nprime] = x;//nprime keeps a count of the index of the non-prime numbers
                nprime++;
                break;
            }
        }
    }
    if(f==0)
    {
        newarr[0][prime] = x;
        prime++;
    }
    sixrecur(n,i+1,ar,newarr,nprime,prime);
}


int main() {


int ar[] = {8, 2, 3, 6, 7, 11, 21, 22, 28, 23, 12, 43, 9, 17, 25, 27, 29, 47, 10, 31};
    int newarr[2][20];
    int prime = sixrecur(20,0,ar,newarr,0,0);
    for(int j=0;j<prime;j++)
    {
        printf("%d ",newarr[0][j]);
    }
    printf("\n");
    for(int j=0;j<20-prime;j++)
    {
        printf("%d ",newarr[1][j]);
    }
    printf("\n");
    return 0;
}*/

	// Problem 7
/*int sevenrecur(int m,int n)
{
    if(m==1 || n==1)
    {
        return 1;
    }
    return sevenrecur(m,n-1)+sevenrecur(m-1,n);
}
int sevencost(int m,int n,int cost, int c)
{
    if(m==1 || n==1)
    {
        return c;
    }
    return sevencost(m,n-1,cost,c)+sevencost(m-1,n,cost,c);
}

int main () {
srand(time(0));
    int m = rand()%7 +4;
    int n = rand()%7 +4;
    printf("you have a %d*%d grid \n",m,n);
    int a = rand()%m;
    int b = rand()%n;
    int c = rand()%m;
    int d = rand()%n;
    printf("%d is a, %d is b\n",a,b);
    printf("%d is a, %d is b\n",c,d);
    int newm = a>c?a-c:c-a;
    int newn = b>d?b-d:d-b;
    //printf("%d, %d ",newm,newn);
    printf("there are %d paths between %d,%d and %d,%d \n",sevenrecur(newm+1,newn+1),a,b,c,d);
    int cost = rand() % 9 + 1;
    printf("the total cost of moving from these two points is %d assuming cost to be %d from each point\n",sevencost(newm+1,newn+1,0,cost)*(newm+newn+2),cost);
    return 0;

}*/
