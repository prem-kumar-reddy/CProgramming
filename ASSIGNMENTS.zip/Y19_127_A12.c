#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
	//Problem 1

/*void main()
{
	char c1,c2,s1[64],s2[64];
	int a=0;
	FILE *f1,*f2;
	printf("Enter two .txt FILES to compare and get Difference : ");
	scanf("%s %s",s1,s2);
	f1 = fopen(s1,"r");
	f2 = fopen(s2,"r");
	while((c1 = fgetc(f1)) != EOF && (c2 = fgetc(f2)) != EOF)
	   {
		if(c1 != c2)
		{printf("'%c'\n",c1);
		  while(c1 != '\n')
		   {  putchar(c1);
		     c1 = fgetc(f1); }
		 printf("\n'%c'\n",c2);
		  while(c2 != '\n')
		   {  putchar(c2);
		     c2 = fgetc(f2); }
		  a++;
		 break;}
	    }
	printf("\n");
	if(a==0)
	printf("\nNO differences in above two TXT files\n\n"); 
	fclose(f1);
	fclose(f2);
	
}*/

	//Problem 2
/*#define lnsperpage 10
void main(int argc , char *argv[])
{
	FILE *f;
	int i;
	char c;
	if(argc == 1)
	{  printf("Please Enter .txt files \n");
	  exit(1); }
	for(i=1;i<argc;i++)
	 { int n=1,nols=0; 
	   if((f = fopen(*++argv,"r")) == NULL)
	     printf("Unable to Open File\nplease MAKE SURE that file is existing\n");
	     printf("\n\n\t\t\t\t\t\t TITILE : %s\n\n\t",*argv);
		 while((c = fgetc(f)) != EOF)
		{  printf("%c",c);
		    if(c == '\n')
			nols++;
		    if(nols == lnsperpage)
		     { printf("\n   PAGE %d\n\n\n",n);
	      		n++;
			nols=0; }
		 }
	    fclose(f);

	   }
}*/

	//Problem 3
/*void main()
{
	FILE *f;
	f = fopen("compress.dna","w");
	fprintf(f,"actcatacgatcttcaagctactcgcacagacgtggtatggtcagagaaaagggggcttg");
	fprintf(f,"aattttagtgtgccagttagtcagcaggctaaacaaactagtagcaggataggataccaa");
	fprintf(f,"ggtctgtacaatagagctgtgtcacggattccataccaacaatcccggagtcctttactg");
	fprintf(f,"catccgatctggtcgtgaggaaactgaagggtaagaccgctacctactccccgtctatcg");
	fprintf(f,"gcgtactgagggtgtctctgttcctggtgtagactttccgaaggtgttgagacccgggtc");
	fprintf(f,"ttatatgccgtgcctcgatgcgggtggattaggtcagtagcgtcatcaagtggtaaattg");
	fprintf(f,"tcttggcgagcccgtcaactgtttacggcagaactgggtaggagcgcgggaaatttgacg");
	fprintf(f,"tgcctgaagcgattaagtggggccgactgcggtacgctacgtgcggaggacttcatacgc");
	fprintf(f,"gtcaggcccacctattggatgttcactacaccttaaagtgtgaaacacaaaccaatttat");
	fprintf(f,"gaacatcggactgccggcatagcttatcgggaactacatgaatggggaagtgttcgttac");
	fprintf(f,"ggataactctcggccatgctacgggaaagtttctactacagccggtgcgtccgagccctt");
	fprintf(f,"ctgaacttagcagactcttcgaacaccaatgggcttcagaccattcaaatgagttgcttt");
	fprintf(f,"ccaaggtctcgcgccctcggagttcatgtctttgggaatttaggaagacgcgagtatagc");
	fprintf(f,"ccatgctcgcgacttatatacccgctcattcgaccgtattattcgcccaaacacctgtcg");
	fprintf(f,"ctccgctgtgtcatcccgtccgtggtgcgatttcggatgtcaccagactgtcagtaacga");
	fprintf(f,"gtcacagttcccaaacgcacggtggacgttccgtgacctaaatttaatacatttgcatct");
	fprintf(f,"gcacactaccaatggggcaagccttcaaaccattgcatgt");

	fclose(f);
	f = fopen("compress.dna","r");
	int n=0;
	char c,a;
	while((c = fgetc(f)) != EOF)
	  {  if(c != a && n != 0)
		{ printf("%d%c",n,a);
		  n=0; }
	    a = c;
	    n++;
    	  }
	printf("\n");
	fclose(f);
}*/

	//Problem 4
/*void main(int argc,char *argv[])
{
	FILE *f,*fc;
	char *filetype,*dna=".dna",*dnare=".dnare";
	int n=0;
	char c,a;
	if(argc ==1)
	  {  printf("Enter a Valid arguement\n");
	      exit(1);  }
	filetype = strchr(*++argv,'.');
	if((strcmp(filetype,dna))==0)
	  { f = fopen(*argv,"r");
	    fc = fopen("extension.dnare","a");
		while((c = fgetc(f)) != EOF)
		  {  if(c != a && n != 0)
			{ fprintf(fc,"%d%c",n,a);
			  n=0; }
	    	     a = c;
	    	     n++;
    	  	   }
	     printf("\n");
	     fclose(f);
	     fclose(fc);
	   }
	if((strcmp(filetype,dnare))==0)
	  {  f = fopen(*argv,"r");
	     fc = fopen("compression.dna","a");
		while((fscanf(f,"%d",&n)) != EOF && (fscanf(f,"%c",&c)) != EOF)
		 { while(n>0)
		    { fprintf(fc,"%c",c);
		      n--; }
		  }
	      printf("\n");
	      fclose(f);
	      fclose(fc);
	   }
}*/

	//Problem 5
/*void main(int argc, char *argv[]) 
{
	if(argc != 3 && argc != 4) 
	   {  printf("ERROR!\tInvalid number of Arguments !\n");
		exit(1);
	    }
FILE *f1, *f2, *fc1, *fc2;
char c,*ext1,*ext2,temp,j[64];
int count = 0,n;

	if(argc == 3) 
	   {  ext1 = strchr(argv[1],'.');
	      ext2 = strchr(argv[2],'.');
		if(!strcmp((ext1 + 1), "dna") && !strcmp((ext2 + 1), "dna")) 
		  {   f1 = fopen(argv[1], "a");
		      f2 = fopen(argv[2], "r");
			if(f1 == NULL || f2 == NULL) 
			  {  printf("ERROR\n");
			     exit(1); }

			while((c = fgetc(f2)) != EOF) 
			  {  fprintf(f1,"%c",c);
			     printf("%c",c);  }
			fclose(f1);
			fclose(f2);
		      printf("\n\n\t\tThe Output File is %s\n",argv[1]);
		   } 
		
		else if(!strcmp((ext1 + 1), "dnare") && !strcmp((ext2 + 1), "dnare")) 
		  {  f1 = fopen(argv[1], "r");
		     f2 = fopen(argv[2], "r");
		     fc1 = fopen("result1.dna", "w");
		     fc2 = fopen("result2.dna", "w");
			
			while(fscanf(f1,"%d",&count) != EOF && fscanf(f1,"%c",&c) != EOF) 
		          {  while(count > 0) 
			       {  fprintf(fc1,"%c",c);
			          --count;  }
			   }

			while(fscanf(f2,"%d",&count) != EOF && fscanf(f2,"%c",&c) != EOF) 
			  {  while(count > 0) 
			       {  fprintf(fc2,"%c",c);
				  --count; }
			   }
			fclose(fc2);
			fc2 = fopen("result2.dna", "r");

			while((c = getc(fc2)) != EOF) 
			  {  fprintf(fc1,"%c",c); }
			fclose(f1);
			fclose(f2);
			fclose(fc1);
			fclose(fc2);
		      strcpy(j,argv[1]);
		      n = strlen(j);
			j[n-2] = '\0';  
		     f1 = fopen(j,"w");
		     fc1 = fopen("result1.dna","r");
			while(fscanf(fc1,"%c",&c) != EOF)
			  {  fprintf(f1,"%c",c);
			     printf("%c",c);  }

			printf("\n\nThe Outputfile is %s\n",j);

		  } 
		else if(!strcmp((ext1 + 1), "dna") && !strcmp((ext2 + 1), "dnare")) 
		  {  f1 = fopen(argv[1], "a");
		     f2 = fopen(argv[2], "r");
		     fc2 = fopen("result2.dna", "w");

			while(fscanf(f2,"%d",&count) != EOF && fscanf(f2,"%c",&c) != EOF) 
			  {  while(count > 0) 
			      {	fprintf(fc2,"%c",c);
					--count;  }
			   }
			fclose(fc2);
			fc2 = fopen("result2.dna", "r");

			while((c = getc(fc2)) != EOF) 
			  {  fprintf(f1,"%c",c);
		             printf("%c",c); }
			fclose(f1);
			fclose(f2);
			fclose(fc2);
		     
		     printf("\n\n\t\tThe Output File is %s\n",argv[1]);
		  } 
		else if(!strcmp((ext1 + 1), "dnare") && !strcmp((ext2 + 1), "dna")) 
		  {  f1 = fopen(argv[1], "r");
		     f2 = fopen(argv[2], "r");
		     fc1 = fopen("result1.dna", "w");

			while(fscanf(f1,"%d",&count) != EOF && fscanf(f1,"%c",&c) != EOF) 
			  {  while(count > 0) 
			      {	fprintf(fc1,"%c",c);
				--count;  }
			   }
			fclose(fc1);
			fc1 = fopen("result1.dna", "a");

			while((c = getc(f2)) != EOF) 
			  { fprintf(fc1,"%c",c); }
			fclose(f1);
			fclose(f2);
			fclose(fc1);
	
			strcpy(j,argv[1]);
		      n = strlen(j);
			j[n-2] = '\0';  
		     f1 = fopen(j,"w");
		     fc1 = fopen("result1.dna","r");
			while(fscanf(fc1,"%c",&c) != EOF)
			  {  fprintf(f1,"%c",c);
			     printf("%c",c);  }

			printf("\n\nThe Outputfile is %s\n",j);

		}

	} 
	else if(argc == 4 && (!strcmp(argv[1], "-compressed") || !strcmp(argv[2], "-compressed") || !strcmp(argv[3], "-compressed"))) 
	  {  if(!strcmp(argv[1], "-compressed")) 
		{  argv[1] = argv[2];
	  	   argv[2] = argv[3];  } 
	     else if(!strcmp(argv[2], "-compressed")) 
			argv[2] = argv[3];
		
		ext1 = strchr(argv[1],'.');
		ext2 = strchr(argv[2],'.');
		
	
		if(!strcmp((ext1 + 1), "dnare") && !strcmp((ext2 + 1), "dnare")) 
		  {  f1 = fopen(argv[1], "a");
		     f2 = fopen(argv[2], "r");	

			while((c = getc(f2)) != EOF) {
				fprintf(f1,"%c",c);

			}
			fclose(f1);
			fclose(f2);
		     printf("\n\n\t\tThe Output File is %s\n",argv[1]);
		  } 
		else if(!strcmp((ext1 + 1), "dna") && !strcmp((ext2 + 1), "dna")) 
		  {  f1 = fopen(argv[1], "r");
		     f2 = fopen(argv[2], "r");
		     fc1 = fopen("result1.dnare", "w");
		     fc2 = fopen("result2.dnare", "w");

			while((c = getc(f1)) != EOF) 
			  {  if(c != temp && count != 0) 
				{ fprintf(fc1,"%d%c",count,temp);
					count = 0; }
				temp = c;
				++count;
			   }
			count = 0;
			while((c = getc(f2)) != EOF) 
			  {  if(c != temp && count != 0) 
				{  fprintf(fc2,"%d%c",count,temp);
				   count = 0; }
				temp = c;
				++count;
			   }
			fclose(f1);
			fclose(f2);
			fclose(fc1);
			fclose(fc2);

			fc1 = fopen("result1.dnare", "a");
			fc2 = fopen("result2.dnare", "r");

			while((c = getc(fc2)) != EOF) 
			  {  fprintf(fc1,"%c",c); }			
			fclose(fc1);
			fclose(fc2);

			strcpy(j,argv[1]);
		      n = strlen(j);
			j[n] = 'r';
			j[n+1] = 'e';  
		     f1 = fopen(j,"w");
		     fc1 = fopen("result1.dnare","r");
			while(fscanf(fc1,"%c",&c) != EOF)
			  {  fprintf(f1,"%c",c);
			     printf("%c",c);  }

			printf("\n\nThe Outputfile is %s\n",j);
	
 		 } 
		else if(!strcmp((ext1 + 1), "dnare") && !strcmp((ext2 + 1), "dna")) 
		  { f1 = fopen(argv[1], "a");
		    f2 = fopen(argv[2],"r");
		    fc2 = fopen("result2.dnare","w");

			while((c = getc(f2)) != EOF) 
			  {  if(c != temp && count != 0) 
			       {  fprintf(fc2,"%d%c",count,temp);
			   	  count = 0;  }
				temp = c;
				++count;
			   }
			fclose(f2);
			fclose(fc2);
			
			fc2 = fopen("result2.dnare", "r");

			while((c = getc(fc2)) != EOF) 
			  {  fprintf(f1,"%c",c);
			     printf("%c",c); }			
			fclose(f1);
			fclose(fc2);			
		     printf("\n\n\t\tThe Output File is %s\n",argv[1]);
		 } 
		else if(!strcmp((ext1 + 1), "dna") && !strcmp((ext2 + 1), "dnare")) 
		  {  f1 = fopen(argv[1], "r");
		     f2 = fopen(argv[2],"r");
		     fc1 = fopen("result1.dnare","w");

			while((c = getc(f1)) != EOF) 
			  {   if(c != temp && count != 0) 
				{  fprintf(fc1,"%d%c",count,temp);
			  	   count = 0;  }
				temp = c;
				++count;
		 	   }
			fclose(f1);
			fclose(fc1);
			
			fc1 = fopen("result1.dnare", "a");

			while((c = getc(f2)) != EOF) 
			  {  fprintf(fc1,"%c",c);
			     printf("%c",c); }			
			fclose(f2);
			fclose(fc1);	

			strcpy(j,argv[1]);
		      n = strlen(j);
			j[n] = 'r';
			j[n+1] = 'e';  
		     f1 = fopen(j,"w");
		     fc1 = fopen("result1.dna","r");
			while(fscanf(fc1,"%c",&c) != EOF)
			  {  fprintf(f1,"%c",c);
			     printf("%c",c);  }

			printf("\n\nThe Outputfile is %s\n",j);
		  } 
		else printf("!ERROR! NO SUCH FLAG FOUND\n");
	}

}*/

	// Problem 6
void main(int argc, char *argv[]) 
{
	if(argc == 1) 
	  {  printf("Please pass the file name as the command line argument\n");
	     exit(1); }

	FILE *fp;

	fp = fopen(argv[1],"r");

	switch(errno) 
         {
	   case 0: printf("NO ERROR IN OPENING THE FILE\n");
		    break;	
	   case 2: printf("NO SUCH FILE OR DIRECTORY\n");
		    break;
	   case 7: printf("ARGUMENT LIST TOO LONG\n");
	 	    break;
	   case 11: printf("TRY AGAIN\n");
		     break;
	   case 12: printf("OUT OF MEMORY\n");
		     break;
	   case 13: printf("PERMISSION DENIED\n");
 		     break;
	 }

	fclose(fp);
}
