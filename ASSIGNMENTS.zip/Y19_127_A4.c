#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	/* Problem 1 */
	printf("\nProblem 1\n\n");
	/* To find temperature in celsius from fahrenheit */
	float F,C;
	printf("Enter the temperature in fahrenheit\n");
	scanf("%f",&F);
	C = (F-32)*5/9;
	printf("the temperature is %.2f°c\n",C);
	
	/* Problem 2 */
	
	printf("\nProblem 2\n\n");
	int a,b,c;
	printf("enter the values of x,y,z\n");
	scanf("%d%d%d",&a,&b,&c);
	printf("Given values of x,y,z are %d,%d,%d\n",a,b,c);

	 if (b==1) 
		{	a=b+1;
		 	c=a++;
	  		printf("the values of x,y,z are %d,%d,%d\n",a,b,c);
		}
	
	else
       		{	c = b++;
	   		printf("the values of x,y,z are %d,%d,%d\n",a,b,c);
		}
	
	  /* Problem 3 */
	 printf("\nProblem 3\n\n");

	int x,y,z;
	printf("enter the values of x,y,z\n");
	scanf("%d%d%d",&x,&y,&z);
	z = (x+y+z)/4%++x*2-1;
	printf("the value of expression is %d\n",z);
	
	printf("re-enter the values of x,y,z\n");
	scanf("%d%d%d",&x,&y,&z);	
	if ( x>y && x>z )
	{printf("the largest value is %d\n",x);}
	else if (y>x && y>z)
	{printf("the largest value is %d\n",y);}
	else if (z>x && z>y)
	{printf("the largest value is %d\n",z);}

	if ( x<y && x<z )
	{printf("the smallest value is %d\n",x);}
	else if (y<x && y<z)
	{printf("the smallest value is %d\n",y);}
	else if (z<x && z<y)
	{printf("the smallest value is %d\n",z);}
	
	/* Problem 4 */
	printf("\nProblem 4\n\n");
	
	int d=15,e=70,f=105,i=1,j=50;

	printf("Before execution a=%d, b=%d, c=%d\n",d,e,f);

	++d;
	d = d + ++d;
	d = d + e--;
	d = d - f--;
	printf("after execution a=%d, b=%d, c=%d\n",d,e,f);

	printf("\nbefore execution i=%d, j=%d\n",i,j);
	i = 2+2*i++;
	d = ++i + ++i + ++i;
	j = ++i + ++i + ++i;
	printf("after execution a=%d, i=%d, j=%d\n",d,i,j);

	/* Problem 5 */
	printf("\nProblem 5\n\n");

	int l;
	float m,n;
	l=1256;
	n=2.3543;
	printf("size of 1256=%ld\n",sizeof l);
	printf("size of 2.3543=%ld\n",sizeof n);
	m=n-(int)n;
	printf("the decimal part of 2.3543 is %.4f\n",m);
	
	char S[13];
	
	printf("enter the 13 characters\n");
	scanf("%5s",S);
	printf("%s\n",S);
	

	/* Problem 6 */
	printf("\nProblem 6\n\n");
	
	int p=20,q=10,r=15,s=5,t;
	t=(p+q)*r/s;
	p = 5 * 3 + 2 - 4;
	p = 2 + 4 + 3 * 5 / 3 - 5;
	p = 5 * 3 % 6 - 8 + 3;
	q = 3%(0*1-4*2);
	q = 3 && 5 & 4 % 3;
	q = 5 & 3 && 4 || 5 || 6;
	printf("the values of a=%d, b=%d, c=%d, d=%d, e=%d\n",p,q,r,s,t);

	/* Problem 7 */
	printf("\nProblem 7\n\n");
	
	/* To find temperature from celsius to fahrenheit */
	float g,h;
	printf("Enter the temperature in celsius\n");
	scanf("%f",&g);
	h = g*9/5+32;
	printf("the temperature in fahrenheit is %.2f\n",h);

	/* Problem 8 */
	
	printf("\nProblem 8\n\n");
	int a1,b1,c1;
	printf("enter the values of a,b,c\n");
	scanf("%d%d%d",&a1,&b1,&c1);
	printf("Given values of a,b,c are %d,%d,%d\n",a1,b1,c1);

	 if (c1>=5) 
		{	a1=b1++ + 1;
		 	b1=a1++ * 2;
			c1= ++b1;
	  		printf("the values of a,b,c are %d,%d,%d\n",a1,b1,c1);
		}
	
	else
       		{	c1 = ++b1 + 1 + ++a1;
	   		printf("the values of a,b,c are %d,%d,%d\n",a1,b1,c1);
		}

	  /* Problem 9 */
	 printf("\nProblem 9\n\n");

	int xx,yy,zz;
	printf("enter the values of a,b,c\n");
	scanf("%d%d%d",&xx,&yy,&zz);
	zz = xx/yy*zz/5%++xx*2-y++*3;
	printf("the value of expression c= %d\n",zz);
	
	printf("re-enter the values of a,b,c\n");
	scanf("%d%d%d",&xx,&yy,&zz);	
	if ( xx>yy && xx>zz )
	{printf("the largest value is %d\n",xx);}
	else if (yy>xx && y>zz)
	{printf("the largest value is %d\n",yy);}
	else if (zz>xx && zz>yy)
	{printf("the largest value is %d\n",zz);}

	if ( xx<yy && xx<zz )
	{printf("the smallest value is %d\n",xx);}
	else if (yy<xx && yy<zz)
	{printf("the smallest value is %d\n",yy);}
	else if (zz<xx && zz<yy)
	{printf("the smallest value is %d\n",zz);}

	/* Problem 10 */
	printf("\nProblem 10\n\n");
	
	int mm=15,nn=70,kk=105;

	printf("Before execution m=%d, n=%d, k=%d\n",mm,nn,kk);

	++mm;
	mm = mm + kk++;
	mm = mm + nn--;
	mm = mm - ++kk;
	printf("After execution m=%d, n=%d, k=%d\n",mm,nn,kk);

	/* Problem 11 */
	printf("\nProblem 11\n\n");

	int ll;
	float pp,qq;
	ll=978;
	qq=3.142;
	printf("size of 978=%ld\n",sizeof ll);
	printf("size of 3.142=%ld\n",sizeof qq);
	pp=qq-(int)qq;
	printf("the decimal part of 3.142 is %.4f\n",pp);
	
	int jj;
	printf("enter no .of characters 'n' (7<n<20)\n");
	scanf("%d",&jj);
	char T[jj];
	printf("enter %d characters\n",jj);
	scanf("%4s",&T[jj]);
	printf("%s",T);


	/* Problem 12 */
	printf("\nProblem 12\n\n");
	
	int x1=20,y1=10,z1=15,k1=5,out;
	out=(x1+y1)*z1/k1;
	x1 = y1++*(x1+2)/3/2;
	y1 = (++y1+x1)*2+4;
	z1 = y--+x1/2;
	k1 = ++z1*(x1+y1)*z1/2;
	printf("the values of x=%d, y=%d, z=%d, k=%d, out=%d\n",x1,y1,z1,k1,out);

	/* Problem 13 */
	printf("\nProblem 13\n\n");
	
	char ho[5];
	int o;
	printf("Enter five characters\n");
	for (o=1;o<6;o++)
	{	
		scanf("%c",&ho[o]);
	}
	
	for (o=5;o>0;o--)
	{
		printf("the given characters in reverse order is %c\n",ho[o]);
	}
	
	/* Problem 14 */
	printf("\nProblem 14\n\n");

	char hi[5];
	int u;
	printf("Enter five characters\n");
	for (u=0;u<5;u++)
	{	
		hi[u]=getchar();
	}
	
	for (u=4;u>=0;u--)
	{
		putchar(hi[u]);
	}

	/* Problem 15 */
	printf("\nProblem 15\n\n");

	char A;
	printf("Enter the alphabet\n");
	scanf("%c",&A);
	if(65<=A<90||97<=A<122)
	{	
		A=A+1;
		printf("the next alphabet is %c\n",A);
	}
	else
	{ printf("there is no alphabet after z\n");  }

	/* Problem 16 */
	printf("\nProblem 16\n\n");
	
	int v,w;
	printf("enter two integers\n");
	scanf("%d%d",&v,&w);
	printf("NOR operation for given two integers is %d\n",!(v||w));

	return 0;
}

