#include<stdio.h>
#include<math.h>
int main()
{
	/* Problem-1 */
	
	/*int m;
	printf("Enter the value an integer(m): \n");
	scanf("%d",&m);
	if (m>0)
	  printf("The value of n is 1\n");
	else if (m==0)
	  printf("The value of n is 0\n");
	else if (m<0)
	  printf("The value of n is -1\n");*/

	/* Problem-2*/
	/* categorization of a person by height in c.m.s */
	/*int h;
	printf("Enter the Height of a person in (c.m.s): \n");
	scanf("%d",&h);
	if(h>=170)
	printf("The person is tall\n");
	else if(160<=h<170)
	printf("The person is in average height category\n");
	else (h<160)
	printf("The person is in below average height category\n");*/

	/*Problem-3 */
	/* To check the co-ordinate point lies in which Quadrant in coordinate system*/
	/*int x,y;
	printf("Enter a Co-ordinate point(x y): \n");
	scanf("%d%d",&x,&y);
	if (x>0 & y>0)
	  printf("The Point lies in First Quadrant\n");
	else if (x<0 & y>0)
	  printf("The Point lies in Second Quadrant\n");	
	else if (x<0 & y<0)
	  printf("The Point lies in Third Quadrant\n");
	else (x>0 & y<0)
	  printf("The Point lies in Fourth Quadrant\n");*/

	/* Problem-4 */
	/* To check the given triangle is Equilateral/Isosceles/Scalene */
	/*int a,b,c;
	printf("Enter length of sides of a triangle\n");
	scanf("%d%d%d",&a,&b,&c);
	if(a==b & b==c)
	  printf("The trianle is Equilateral\n");
	else if(a==b || b==c || c==a)
	  printf("The trianle is Isosceles\n");
	else (a!=b & b!=c & c!=a)
	  printf("The trianle is Scalene\n");*/

	/* Problem-5 */
	/* To check whether given 3 angles can form a triangle or not */
	/*int a,b,c;
	printf("Enter the angles a,b,c\n");
	scanf("%d%d%d",&a,&b,&c);
	if (a+b+c == 180 & a+b>c & b+c>a & c+a>b)
	  printf("Triangle can be formed with the given angles\n");
	else 
	  printf("Triangle cannot be formed with the given angles\n");*/

	/* Problem-6 */
	/* To check given character is an alphabet or a digit or special character */
	/*char a;
	printf("Enter a character\n");
	scanf("%c",&a);
	if (a>=65 & a<=122)
	  printf("You have entered an Alphabet\n");
	else if (a>=48 & a<=57)
	  printf("You have entered a Digit\n");
	else
	  printf("You have entered a Special Character\n");*/

	/* Problem-7 */
	/* To check whether input number is Even or Odd */
	/*int a;
	printf("Enter a number\n");
	scanf("%d",&a);
	if (a%2==0)
	  printf("It is an Even Number\n");
	else
	  printf("It is a Odd Number\n");*/

	/* Problem-8 */
	/* To Check whether it is Right angled triangle by input of 3 integers */
	/*int a,b,c;
	printf("Enter 3 integers\n");
	scanf("%d%d%d",&a,&b,&c);
	if (a*a==b*b+c*c || b*b==c*c+a*a || c*c==b*b+a*a)
	  printf("They are the sides of a Right Angled Triangle\n");
	else 
	  printf("They are not the sides of a Right Angled Triangle\n");*/

	/* Problem-9*/
	/* To display the name of the week day by input of integers 1 to 7 */
	/*int n;
	printf("Enter a natural number below 8\n");
	scanf("%d",&n);
	switch (n)
	  {
	    case 1: printf("It is Monday\n"); break;
	    case 2: printf("It is Tuesday\n"); break;
	    case 3: printf("It is Wednesday\n"); break;
	    case 4: printf("It is Thursday\n"); break;
	    case 5: printf("It is Friday\n"); break;
	    case 6: printf("It is Saturday\n"); break;
	    case 7: printf("It is Sunday\n"); break;
	  }*/

	/* Problem-10 */
	/*To calculate Electricity charge for an user and display the charges*/
	/*char name[15];
	float a,b,c;
	printf("Enter the name of user\n");
	scanf("%s",name);
	printf("Enter Electric units consumed by user\n");
	scanf("%f",&a);
	if (a<=200)
	 c=0.8;
	else if (a>200 & a<=300)
	  c=0.9;
	else if (a>300)
	  c=1.0;
	b=c*a+100;

	if (b>400)
	  {b=b+b*15/100;
	  printf("Total Electricity bill charge for %s is %.2f\n",name,b);}
	else 
	printf("Total Electricity bill charge for %s is %.2f\n",name,b);*/

	/* Problem-11 */
	/*To count number of Capital and small alphabets in given input */
	/*char word[5];
	int count1=0,count2=0;
	printf("Enter a word of 5 letters\n");
	scanf("%s",word);
	if ( word[0]>=97 & word[0]<=122)
	  count1++;
	if ( word[1]>=97 & word[1]<=122)
	  count1++;
	if ( word[2]>=97 & word[2]<=122)
	  count1++;
	if ( word[3]>=97 & word[3]<=122)
	  count1++;
	if ( word[4]>=97 & word[4]<=122)
	  count1++;
	if ( word[0]>=65 & word[0]<=90)
	  count2++;
	if ( word[1]>=65 & word[1]<=90)
	  count2++;
	if ( word[2]>=65 & word[2]<=90)
	  count2++;
	if ( word[3]>=65 & word[3]<=90)
	  count2++;
	if ( word[4]>=65 & word[4]<=90)
	  count2++;
	
	  printf("The No. of CAPITALS are %d\nThe No. of SMALLS are %d\n",count2,count1);*/
	
	/* Problem-12*/
	/*This to verify whether a no. is divisible by 6 and not divisible by 4*/
	/*int y;
	printf("Enter the integer: ");
	scanf("%d", &y);
	if(y%6==0 && y%4!=0)
	  printf("The given integer is divisible by 6 and not divisible by 4\n");
	else
	  printf("The given integer does not satisfy the given condition\n");*/

	/*Problem-13 (USING IF-ELSE CASE)*/
	/*this program is used to find the sin, cosine and tan of x in radians*/
	/*float r,result;
	char D;
	printf("Enter the character: ");
	scanf("%c", &D);
	if(D==s || D==S)
		result=sin(r);
	else if (D==c || D==C)
		result=cos(r);
	else if (D==t || D==T)
		result=tan(r);
	else 
		printf("NO CALCULATION SPECIFIED\n");
	printf("The result is %f\n",result);*/

	/*Problem-14 (USING SWITCH CASE)*/
	/*float r1,result1;
	char M;
	printf("Enter the character: ");
	scanf("%c", &M);
	switch(M)	
	{
		case 's':
		case 'S': result1=sin(r1);
			printf("The result is %f\n",result1);
			break;
		case 'c':
		case 'C': result1=cos(r1);
			printf("The result is %f\n",result1);
			break;
		case 't':
		case 'T': result1=tan(r1);
			printf("The result is %f\n",result1);
			break;	
	}*/

	// BONUS PROBLEM

	/*int age,income;
	float tax,tax1;
	printf("Enter the income and age:");
	scanf("%d %d",&income,&age);
	if(age<=60)
	{
	if(income<=250000)
	    tax=0;
	else if(income>250000&&income<=500000)
	{  tax1=(0.05)*(income-250000);
	   tax=0.04*tax1;
	   tax=tax+tax1;
	}
	else if(income>500000&&income<=1000000)
	{  tax1=0.2*(income-500000);
	   tax=0.04*tax1;
	   tax=tax+tax1;
	}
	else
	{  tax1=0.1*(income-1000000);
	   tax=0.04*tax1;
	   tax=tax+tax1+112500;
	}
	}
	else
	{if(60<age<=80)
	 {if(income<=300000)
	    tax=0;
	  else if(income>300000&&income<=500000)
	 {  tax1=(0.05)*(income-300000);
	    tax=0.04*tax1;
	    tax=tax+tax1;
	 }
	 else if(income>500000&&income<=1000000)
	 { tax1=0.2*(income-500000);
	   tax=0.04*tax1;
	   tax=tax+tax1+10000;
	 }
	 else
	  { tax1=0.1*(income-1000000);
	    tax=0.04*tax1;
	    tax=tax+tax1+112500;
	  }
	 } 
	}
	if(age>80)
	{
	  if(income<=500000)
	   tax=0;
	  else if(income>500000&&income<=1000000)
	    { tax1=0.2*(income-500000);
	        tax=0.04*tax1;
		tax=tax+tax1+10000;
	    }  
	   else
	    {tax1=0.1*(income-500000);
	     tax=0.04*tax;
	     tax=tax+tax1+100000;
	    }	
	 }
	printf("the total tax person has to pay is %f\n",tax);*/       


	return 0;
}
