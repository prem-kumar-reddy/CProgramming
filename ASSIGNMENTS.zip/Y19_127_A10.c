#include<stdio.h>
#include<string.h>

//Problem 1

/*void cycle(int *a,int *b,int *c)
{	int t;
	t=*a; *a=*c; *c=*b; *b=t;
}

void main()
{
	int a,b,c;
	printf("Enter any 3 integers : ");
	scanf("%d%d%d",&a,&b,&c);
	printf("Entered numbers are %d %d %d\n",a,b,c);
	cycle(&a,&b,&c);
	printf("Entered numbers after one cycle are %d %d %d\n",a,b,c);
}*/

// Problem 2

/*void fact(int *n,int *r)
{	if(*n!=0)
	{ *r = (*n)*(*r);
	  *n = (*n) - 1;
	 fact(n,r);
	}
}

void main()
{	int n,a,r=1;
	printf("Enter a number to get factorial of it n = ");
	scanf("%d",&n);
	a=n;
	fact(&n,&r);
	printf("Factorial of %d is %d\n",a,r);
}*/

// Problem 3

/*void func(int *p, int *n)
{	int b;
	b=*n;	
	for(b=3;b<30;b++)
	{  p[b]=p[b-1] + p[b-3];
	}
}

void main()
{	int a[30]; int n=3,i=0;
	a[0]=0; a[1]=1; a[2]=1;
	func(a,&n);
	printf("The array formed by given function is"); 
	while(i<30)
    {	printf("%d ",a[i]);
	    i++;
	 }
	 printf("\n");
}*/

// Problem 4

/*void rev(char *a,int *n)
{	int l,r; char k;
	l=0; r=(*n)-1;
	while(l<r)
	{   k = a[l];
		a[l] = a[r];
		a[r] = k;
		l++;
		r--;
	}
}

void main()
{	int n;char a[100];
	printf("Enter characters : ");
	scanf("%s",a);
	n=strlen(a);
	rev(a,&n);
	printf("Reverse order of Entered characters is \n%s\n",a);
}*/


//Problem 5

/*void summation(int *arr, int *sum, int *length) {
	
	for(int i = 0; i < *length; i++) {
		*sum = *sum + arr[i];
	}
}


void pr_5() {

	int arr[100],length,sum = 0;


	printf("Enter The length Of Array Max : [100] : ");
	scanf("%d",&length);

	for(int i = 0; i < length; i++) {

		printf("\nEnter The Value for arr[%d] : ",i);
		scanf("%d",&arr[i]);

	}

	printf("\nMemory Location of variable sum before entering the Function : %p\n",&sum);

	summation(arr, &sum, &length);

printf("Memory Location of variable sum After entering the Function : %p\n",&sum);

printf("The Value of sum : %d\n",sum);

}*/

//Problem 6

/*void pr_6() {

	char str[0][100],newstr[1][100];
	int n,j,a,b,x,length = 0,temp = 0;

	printf("Enter The string : ");

	scanf("\n%[^\n]s",str[0]);

	for(int i = 0;str[0][i] != '\0'; i++) {
		length++;

	}		
	
	printf("\nEnter The values for n : ");
	scanf("%d",&n);

	printf("\nEnter The values for a : ");
	scanf("%d",&a);
	
	printf("\nEnter The values for b : ");
	scanf("%d",&b);
	printf("\n");
	

	while(1) {
		if(length % n == 0) { 
			x = length / n;
			break;
		}
		else {

			length++;	
		}
	}

	int blocks[x][n];

	for(int i = 0; i < x; i++) {

		for(int k = 0; k < n; k++) {
			if(temp < length) {
				blocks[i][k] = str[0][temp];
			}
			else { 
				 blocks[i][k] = '\0';
			}
			temp++;		
		}
	}
	
	printf("The Output is : ");
	
	for(int k = 0; k < x; k++) {
	
		for(int i = 0; i < n; i++) {

			j = (a * i + b) % n;
		
			if(blocks[k][j] == '\0') printf("\\0");
			else
			printf("%c",blocks[k][j]); 			
		}
	}
printf("\n");


}*/