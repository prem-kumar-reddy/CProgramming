#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
typedef struct student_infor{
	char ft_nm[32];
	char lt_nm[32];
	long int Roll_no;
	float cgpa;
	int crs_id[5];
} stud;

int main()
{	int noofstud,n=0,i=0,j,b,count=0,crs[5];
	long int a;
	float median[count];
	char k[32],l[32];
  	 stud *Dts;
printf("\nEnter The Total no. of Students : ");
scanf("%d",&noofstud);
	Dts = (stud *) malloc (noofstud * sizeof(stud));

 while(n != 10)
{	printf("\nEnter below shown Index number so for that point you want to proceed \n\n");
	printf("1. Add Student \n2. Find Student(by RollNo.) \n3. Find Students(by First-Name) \n4. Find Students(by course-id) \n5. Total no. of Students \n6. Delete Student(by RollNo.) \n7. Update Student(by RollNo.) \n8. Show Students Statistics \n9. Show course Summaries\n10. To Quit Enter 10\n");
	scanf("%d",&n);
	if(n==10)
	printf("\nThank You\n");
	switch(n){
	case 1: printf("Enter Student First Name: ");
		scanf("\n%[^\n]s",(Dts+count)->ft_nm);
		printf("Enter Student Last Name: ");
		scanf("\n%[^\n]s",(Dts+count)->lt_nm);
		again:printf("Enter Student Roll Number(leaving S): ");
		scanf("%ld",&(Dts+count)->Roll_no);
		 for(b=0;b<count;b++)
		    { if((Dts+count)->Roll_no == (Dts+b)->Roll_no)
			{printf("This Roll Number is Already Registerd\n");
			 goto again;}
		    }
		printf("Enter Student CGPA:  ");
		scanf("%f",&(Dts+count)->cgpa);
		printf("Enter Student Courses ID[1 - 5] : ");
		for(j=0;j<5;j++)
		   scanf("%d",&(Dts+count)->crs_id[j]);
		count++;
		break;
	case 2:	printf("\nEnter Roll Number: ");
		scanf("%ld",&a);
		b=0;
		 while(b<50)
		    { if(a == (Dts+b)->Roll_no)
			{ printf("\nStudent Name: %s %s \nStudent Roll Number: %ld \nStudent CGPA: %f \n",(Dts+b)->ft_nm,(Dts+b)->lt_nm,(Dts+b)->Roll_no,(Dts+b)->cgpa);
			  printf("Student Registered Courses ID are ");
 	 		   for(j=0;j<5;j++)
		               printf("%d\n",(Dts+b)->crs_id[j]);
			  break;
			}
		      b++;
		    }
		break;

	case 3: printf("\nEnter Student First Name : ");
		scanf("\n%[^\n]s",k);
	        for(b=0;b<50;b++)
		  { a = strcmp(k,(Dts+b)->ft_nm);
		     if(a == 0)
		       { printf("\nStudent Name: %s %s \nStudent Roll Number: %ld \nStudent CGPA: %f \n",(Dts+b)->ft_nm,(Dts+b)->lt_nm,(Dts+b)->Roll_no,(Dts+b)->cgpa);
			  printf("Student Registered Courses ID are \n");
 	 		   for(j=0;j<5;j++)
		               printf("%d\n",(Dts+b)->crs_id[j]);
			break;
			}
		  }
		break;
	case 4: printf("\nEnter Course ID: ");
		scanf("%ld",&a);
		for(b=0;b<50;b++)
		   {for(j=0;j<5;j++)
		     {if(a == (Dts+b)->crs_id[j])
		        printf("\nStudent Name: %s %s - Student Roll Number: %ld \n",(Dts+b)->ft_nm,(Dts+b)->lt_nm,(Dts+b)->Roll_no);
		     }
		   }
		break;
	case 5: i=0;
		while((Dts+i)->Roll_no != 0 && i<50)
			i++;
		if(i==0)
		printf("\nStill NO Student is Registered\n");
		else
		  printf("\nTotal No. of Students registered is %d\n",i);
		break;	
	case 6: printf("\nEnter Roll Number: ");
		scanf("%ld",&a);
		 for(b=0;b<count;b++)
		   {  if(a == (Dts+b)->Roll_no)
			break;
		    }
		 if(b >= count)
		  printf("\n NO such Roll Number is Registered\n");
		else
		  printf("\nThe Student Registered on Roll Number : %ld is DELETED from System\n",a);
		 while(b < count)
			{ for(i=0; (Dts+b+1)->ft_nm[i] != '\0';i++) 
			   { (Dts+b)->ft_nm[i] = (Dts+b+1)->ft_nm[i];
			     (Dts+b)->ft_nm[i+1] = '\0'; }
			  for(i=0; (Dts+b+1)->lt_nm[i] != '\0';i++)
			   { (Dts+b)->lt_nm[i] = (Dts+b+1)->lt_nm[i];
			     (Dts+b)->lt_nm[i+1] = '\0'; }
 
			  (Dts+b)->Roll_no=(Dts+b+1)->Roll_no;
			  (Dts+b)->cgpa=(Dts+b+1)->cgpa;

			  for(i=0; (Dts+b+1)->crs_id[i] != '\0';i++)
			  { (Dts+b)->crs_id[i]=(Dts+b+1)->crs_id[i];
			    (Dts+b)->crs_id[i+1]=0; }
			  
			  if(b == (count-1))
				count--;
			  b++;
		  	}
		 break;
			  
	case 7:	printf("\nEnter indicated number to update that Field\n");
		printf("1. Student First Name \n");
		printf("2. Student Last Name \n");
		printf("3. Student CGPA \n");
		printf("4. Student Roll Number \n");
		printf("5. Student Course ID's\n");
		scanf("%d",&i);	
		switch(i){
		case 1: printf("\nEnter Student Roll Number: \n");
			scanf("%ld",&a);
			for(b=0;b<50;b++)
		    	 { if(a == (Dts+b)->Roll_no)
			   {printf("Enter Student First Name: ");
			    scanf("%s",(Dts+b)->ft_nm);
			    printf("Student profile is updated\n");}
		         }
			break;
		case 2: printf("\nEnter Student Roll Number: \n");
			scanf("%ld",&a);
			for(b=0;b<50;b++)
		    	 { if(a == (Dts+b)->Roll_no)
			   {printf("Enter Student Last Name: ");
			    scanf("%s",(Dts+b)->lt_nm);
			    printf("Student profile is updated\n");}
		         }
			break;
		case 3: printf("\nEnter Student Roll Number: \n");
			scanf("%ld",&a);
			for(b=0;b<50;b++)
		    	 { if(a == (Dts+b)->Roll_no)
			    { printf("\nEnter Student CGPA:  ");
	  		      scanf("%f",&(Dts+i)->cgpa);
			      printf("\n\nStudent profile is updated\n");}
		         }
			break;
		case 4: printf("\nEnter Student Previous Roll Number: \n");
			scanf("%ld",&a);
			for(b=0;b<50;b++)
		    	 { if(a == (Dts+b)->Roll_no)
			    { printf("\nEnter Student New Roll Number :  ");
	  		      scanf("%ld",&(Dts+i)->Roll_no);
			      printf("\n\nStudent profile is updated\n");}
		         }
			break;
		case 5: printf("\nEnter Student Roll Number: \n");
			scanf("%ld",&a);
			for(b=0;b<50;b++)
		    	 { if(a == (Dts+b)->Roll_no)
			    { printf("\nEnter Student Courses ID : \n");
			       for(j=0;j<5;j++)
				{ scanf("%d",&(Dts+b)->crs_id[j]); }
			     }
			  }
			break;
				
		 }
	       break;
	case 8: printf("Statistics of the Students : \n");
		float sum=0,mean,std_dev;
		for(i=0;i<count;i++)
		{  sum=sum+(Dts+i)->cgpa;}
		mean=sum/count;
		printf("\nMean of Students CGPA is %f\n",mean);
		sum=0;
		for(i=0;i<count;i++)
		{ sum=sum+((Dts+i)->cgpa)*((Dts+i)->cgpa);}
		std_dev=sqrt(sum/n+mean*mean);
		printf("\nStandard Deviation of Students CGPA is %f\n",std_dev);
		if(count%2 == 0) 
		  { for(i = 0; i < (count/2)+1; i++)
		      {  median[i] = (Dts+i)->cgpa;
				for(j = 1; j < count; j++)
				    {  if(median[i] > (Dts+j)->cgpa)
					 median[i] = (Dts+j)->cgpa;				
				     }
		       }
				printf("\nMedian of Students CGPA is %f\n",(median[count/2] + median[(count/2)+1]) / 2);
		   }

		if(count%2!=0)
		  { for(i = 0; i < (count/2)+1; i++)
		      {  median[i] = (Dts+i)->cgpa;
				for(j = 1; j < count; j++)
				    {  if(median[i] > (Dts+j)->cgpa)
					 median[i] = (Dts+j)->cgpa;				
				     }
		       }
			    printf("\nMedian of Students CGPA is %f\n",median[count/2]);
		   }
		break;  
	case 9: printf("\nHere is The Course Summary : \n");
		  for(int i = 0; i < 5; i++)
			crs[i] = 0;
		  for(int i = 0; i < 5; i++) 
		    {  for(int j = 0; j < count; j++) 
			 {  for(int k = 0; k < 5; k++) 
			      {  if((Dts+j)->crs_id[k] == (i + 1)) 
				    { crs[i]++;
		  		       break;}
			       }
			  }
		     }

		  for(int i = 0; i < 5; i++)
	  	    printf("\nNumber of Students Registered for course (%d) is : %d",(i+1),crs[i]);	
		break;
}

}
return 0;	
}	  
		
