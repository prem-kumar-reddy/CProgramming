#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
    /* Problem 1 */
/*int main()
{	long long expo(int);
	int k; long long n;
	printf("Enter value of k=");
	scanf("%d",&k);
	n= expo(k);
	printf("2 power of %d (i.e 2^%d) is %ld\n",k,k,n);
}
long long expo(int k)
{
	if (k==0)
	return 1;
	else
	return 1<<k;
}*/

	/* Problem 2 */
/*void palin(char num[])
{ int i,j,a;
	for(i=0;num[i]!='\0';i++){}
for(j=0;j<i/2;j++)
	{if(num[j] != num[i-j-1])
		{a=0;
		break;}
	}
	if(a!=0)
	printf("%s is a Palindrome number \n",num);
	else
	printf("%s is NOT a Palindrome number \n",num);	
}
int main() 
{
	char num[100];
	printf("enter a number = ");
	scanf("%s",num);
	palin(num);
	return 0;
}*/

	/* Problem 3 */
/*void sub(char s1[],char s2[])
{	int i,j,a,b,c=0,d; char k[100];
	for(i=0;s1[i]!='\0';i++){}
	for(j=0;s2[j]!='\0';j++){}
	for(a=0;a<=j;a++)
	  for(b=0;b<=i;b++)
		if(s2[a]==s1[b])
		  { k[c]=s1[b];
			c++;}
	for(d=0;k[d]!='\0';d++)
	printf("%c ",k[d]);
	printf("\n");
}
int main()
{
	char s1[100],s2[100];
	printf("Enter more than 10 characters to save in string1 ");
	scanf("%s",s1);
	printf("Enter more than 10 characters to save in string2 ");
	scanf("%s",s2);
	sub(s1,s2);
	return 0;
}*/

	/* Problem 4 */
/*int mineven( long num[],int n)
{	int b,c,min,flag;	
	for(b=0;b<=n;b++)
	 if(num[b]%2==0)
	   {min=num[b];
		break;}
	for(c=b;c<=n;c++)
	     if(c>b & num[c]%2==0 & num[c]<min)
		   {min=num[c];
		   flag=1;}
	if(flag==1)	
	return min;
	else 
	printf("There are NO even integers \n");
}
int maxeven(long num[],int n)
{	int b,c,max,flag;	
	for(b=0;b<=n;b++)
	 if(num[b]%2==0)
	   {max=num[b];
		break;}
	for(c=b;c<=n;c++)
	     if(c>b & num[c]%2==0 & num[c]>max)
		   {max=num[c];
		   flag=1;}
	if(flag==1)	
	return max;
	else 
	printf("There are NO even integers \n");
}
int gcdof(int min,int max)
{ 	int a=0,b;
	if(max%min==0)
	return min;
	else
	{for(a=0;max%min!=0;a++)
	 {b=min;
	  min=max%min;
	  max=b;
	   if(max%min==0)
	    {return min;
	     break;}}}
}
int main()
{	
	int n,a,min,max,gcd; long x;
	printf("Enter a number between 20 & 30 n=");
	scanf("%d",&n);
	long num[n];
	srand(time(NULL));
	for(a=0;a<n;a++)
	{  x=rand();
	   num[a]=x;
	}	
	min = mineven(num,n);
	max = maxeven(num,n);
	gcd = gcdof(min,max);
	printf("smallest even number is %d\n",min);
	printf("largest even number is %d\n",max);
	printf("GCD of %d and %d is %d\n",min,max,gcd);	
	return 0;
}*/

	/* Problem 5 */
/*void sum_prime(int arr[20])
{
	int i,j, n,number,number2,temp,counter=0, flag=0,c=0,sum=0;
	for(j=0;j<20;j++) 
	    {  n = arr[j];
		for(i=2;i<=(n/2);i++) 
		  {if(n%i == 0) 
		     {flag = 1;
	               break;}}
	
		if(flag == 0) 
	          {number=arr[j];}
	    }
	
	for (i = 0; i < 20; i++) 
	   {for (j = i + 1; j < 20; j++) 
		{if (arr[i] > arr[j]) 
		    {	temp =  arr[i];
        		arr[i] = arr[j];
                        arr[j] = temp;}}
	    }
        for(j=1;j<20;j++) 
	   {n = arr[j];
	      for(i=2;i<=(n/2);i++) 
		{if(n%i == 0) 
			{counter++;}}
		
		if(counter == 0) 
		{number2=arr[j];}
            }
        
        sum = number+number2;
        
        for(i=0;i<20;i++) 
	  {if(sum==arr[i]) 
	    {c++;}
          }
        
        if(c>0)
        {  printf("The sum of pair is present\n");
       	  printf("Sum of %d and %d is %d\n",number,number2,sum);
	}
	
	else 
   	{  printf("Sum of %d and %d is not present in array\n", number, number2);
	}
}

int main() 
{
	int arr[20]={2,15,7,6,3,8,22,41,23,4,18,13,5,27,47,12,11,23,10,9};
	sum_prime(arr);
	return 0;
}*/

	/* Problem 6 */
/* Problem 6 */
/*void sub_array(int arr[20])
{	int i,j,k,count=0;
	for(i=0;i<20;i++) 	
	  {count = 0;
  	    for(j=i,k=i+3;j<(i+3),k>i;j++,k++) 
	       {if(arr[j]==arr[k])
		   {count++;}
	   	}
	     if(count==3) 
	       {printf("%d\n",j);}
	   }	
}
int main() 
{	int arr[30] = {1,3,4,5,6,2,3,8,7,6,5,4,3,2,3,4,2,5,1,8,9,4,3,2,1,5,2,6,7,8};
	sub_array(arr);
	return 0;
}*/

	/* Problem 7 */
/*void square_matrix(int arr1[SIZE*SIZE])
{
	int i,j,k,l,m,n,p,column,row,sum_row=0,sum_column=0;
	 for(i=0;i<SIZE*SIZE;i++) 
		{column = i%SIZE;
		 row = i/SIZE;
		   for(j=row;j<(row+3);j++) 
			{for(k=column;k<(column+3);k++) 
				{if(arr1[(row+1)*(column+1)]%2==0) 
					{for(l=i;l<(i+9);l++) 
						{n = i;
						  for(m=l;m<(l+3);m++) 
						   {  printf("%d",arr1[i]);
						     sum_column = sum_column + arr1[p];
						   }
						
						p=p+3;
						printf("\n");
						l=l+3;
						sum_row = sum_row + arr1[n];
						
						printf("The sum of rows: %d\n",sum_row);
						printf("The sum of columns: %d\n",sum_column);
					        }		
				         }
			
			           }
		         }
	          }	
}
int main() 
{	int k;
	printf("Enter k, the starting index of sub-matrix of order 3\n");
	scanf("%d",&k);
	
	int arr[SIZE][SIZE];
	int number,size1,c;
	size1 = SIZE*SIZE;
	int arr1[size1];
	srand((unsigned int) getpid());
	for(c = 0;c<size1;c++) 
	  {number = rand()%20 + 10;
	    arr1[c] = number;
	}
	square_matrix(arr1);
	return 0;
}*/

