#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main()
{
	/* Problem 1 */
	
	/*int m=2,n=30,b,i,j,a,k,c;
	srand(time(NULL));	
	for(b=10;b>0;b--)
	{  int x = m+rand()%(n-m+1),count=0;
	   printf("%d\n",x);
	   printf("Prime Factors of %d are ",x);
	    for(i=2;i<=x;i++)
	     { if(x%i==0)
		{ a=0;
	          for(j=1;j<=i;j++)
		   { if(i%j==0)
		      a++;
		   }
	        if (a==2)
		 { count++;
		  printf("%d ",i);
		 }
		}
	     }
	printf("Number of prime factors is %d\n",count);	
	 }*/


	/* Problem 2 */

	/*int a = 0,n,m,o,p,x,y,sumf = 0,count = 0,diff;
	
  	printf("\nEnter The Value For 'a' in The Interval [a , b]\n");
	scanf("%d",&x);
	
	printf("\nEnter The Value For 'b' in The Interval [a , b]\n");
	scanf("%d",&y);
	
	diff = y - x + 1;	
	int final[diff];
	
	for(int z = x; z <= y; z++) {
	n = z; 
	a = 0;
	sumf = 0;
	m = o = p = n;
	do {
	
	n = n / 10;
	a++;
	
	
	}while(n != 0);


	int arr[a],sum[a];
	for(int i = 0; i < a; i++) {
	sum[i] = 1;		
		m = m / 10;
		m = m * 10;
		arr[i] = (o - m);
		o = o / 10;
		m = m / 10;
	
	
	for(int j = 0; j < a; j++)
	sum[i] *= arr[i];



	}

for(int k = 0; k < a; k++) {
	sumf += sum[k];
}
   final[count] = sumf;
   count++;
	
  }

printf("\nThe Armstrong Numbers in The Given Range Are : ");
p = x;
for(int q = 0; q < count; q++) {
		
	if(final[q] == p) {
		printf("%d  ",final[q]);
	
	}
	p++;
}
	printf("\n");*/


	/* Problem 3 */

	/*int x,y,z,exp,a,b;
	for(x=2;x<=35;x++)
	  {b=0;
	   for(a=1;a<=x;a++)
	    {if(x%a==0)
		b++;
	    }
	   if(b==2)
	    {  y=2*x;
	       z=x%3;
	       exp=x + --y + ++z/4 % y++ + x*2 - y;
	     if(exp>x&exp>y&exp>z)
		printf("The largest integer is %d\n",exp);
	     else if(x>exp&x>y&x>z)
		printf("The largest integer is %d\n",x);
	     else if(y>exp&y>x&y>z)
	        printf("The largest integer is %d\n",y);
	     else
		printf("The largest integer is %d\n",z);
	      if(exp<x&exp<y&exp<z)
		printf("The smallest integer is %d\n",exp);
	     else if(x<exp&x<y&x<z)
		printf("The smallest integer is %d\n",x);
	     else if(y<exp&y<x&y<z)
	        printf("The smallest integer is %d\n",y);
	     else
		printf("The smallest integer is %d\n",z);
	    }
	  }*/
	
	
	/* Problem 4 */

	/*int n;
	printf("Enter The Number of Rows for Pascal's Triangle : ");
	scanf("%d",&n);

	for(int i = 0; i < n; i++) {
		for(int space = 0; space <= n - i; space++) 
			printf(" ");
		for(int j = 0; j <= i; j++){

		printf("%3d",(fact(i) / (fact(j) * fact(i - j))));
		
		}
		printf("\n");		
	}*/

	/* Problem 5 */
	/*int n,m,odd[10],count = 0,diff,flag,num[10],a = 0,sum = 0;
	printf("Enter An Integer : ");
	scanf("%d",&n);

	m = n;

	printf("The odd digits are : ");
	
	while(n > 0) {
		flag = 0;		
		n = n / 10;
		n = n * 10;
		diff = m - n;
		n = n / 10;
		m = m / 10;
		
		num[count] = diff;
		count += 1;
	}

for(int x = 0; x < count; x++) {

	if(num[x] % 2 == 1) {
		odd[a] = num[x];c,
		printf("%d\t",odd[a]);
		a++;
	}
}

for(int y = 0; y < a; y++) {

	sum += odd[y];
}
	printf("\nThe Sum of All ODD Numbers is : %d\n",sum);*/
	
	
	/* Problem 6 */		
	
	/*int a,b,c,d;
	char x;
	printf("Enter The Values of a, b, c, d Respectively : ");
	scanf("%d %d %d %d",&a, &b, &c, &d);
	printf("\nChoose The Expression\n");
	scanf("\n%c",&x);

	switch (x) {

		case 'a': printf("%d",(a + b / 2 * c - d));
			  break;

		case 'b': printf("%d",(2 * a * a + a));
			  break;

		case 'c': printf("%d",(a / 2 * b - d + c / a));
			  break;

		case 'd': printf("%d",(d / 4 - c * b / a * 3));
			  break;
} */

	/* Problem 7 */		
	/*int arr[3][3];

	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

			printf("\nEnter The Value for The integer in The Position arr[%d][%d] : ",i,j);
			scanf("%d",&arr[i][j]);
		}
	}	



	for(int i = 0; i < 3; i++){
			for(int j = 0; j < 3; j++){

				printf("%d\t",arr[i][j] + 1);

			}
		printf("\n");

	}*/	
	

	/* Problem 8 */		
	/*int mat1[3][3],mat2[3][3],add[3][3];

	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){
			
			printf("\nEnter The Value for The integer in MATRIX 1 for The Position mat1[%d][%d] : ",i,j);
			scanf("%d",&mat1[i][j]);
		}
	}
   	 printf("\n\n\nStart Giving Values For Matrix 2 : \n\n\n");
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

			printf("\nEnter The Value for The integer in MATRIX 2 for The Position mat2[%d][%d] : ",i,j);
			scanf("%d",&mat2[i][j]);
		}
	}	
	 printf("\nThe Addition Of Two Matrices Is : \n\n");
   for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

		add[i][j] = mat1[i][j] + mat2[i][j];
		printf("%d\t",add[i][j]);	
		}
	printf("\n");
	}*/

	
	/* Problem 9 */		
	
	/*int arr[3][3];

	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

			printf("\nEnter The Value for The integer in The Position arr[%d][%d] : ",i,j);
			scanf("%d",&arr[i][j]);
		}
	}	

	for(int i = 2; i >=0; i--){
		for(int j = 0; j < 3; j++){

			printf("%d\t",arr[j][i]);
		}
		printf("\n");
	}*/
	
	
	/* Problem 10 */		

	/*int mat1[3][3],mat2[3][3],mul[3][3];

	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){
			
			printf("\nEnter The Value for The integer in MATRIX 1 for The Position mat1[%d][%d] : ",i,j);
			scanf("%d",&mat1[i][j]);
		}
	}
	printf("\n\n\nStart Giving Values For Matrix 2 : \n\n\n");
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

			printf("\nEnter The Value for The integer in MATRIX 2 for The Position mat2[%d][%d] : ",i,j);
			scanf("%d",&mat2[i][j]);
		}
	}	
	printf("\nThe Multiplication Of Two Matrices Is : \n\n");
  for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){

		mul[i][j] = mat1[i][j] * mat2[j][i];
		printf("%d\t",mul[i][j]);	
		}
	printf("\n");
	}

	
	/* Problem 11 */		

	/*int a[5][5][5][5],b[5][5][5][5],sum[5][5][5][5]; 
	srand(time(0));

	for(int i = 0; i < 5;i++) {
		for(int j = 0; j < 5;j++) {
			for(int k = 0; k < 5;k++) {
				for(int l = 0; l < 5;l++) {
					
					a[i][j][k][l] = (rand() % 10) + 1;
					
					}}}}
	for(int i = 0; i < 5;i++) {
		for(int j = 0; j < 5;j++) {
			for(int k = 0; k < 5;k++) {
				for(int l = 0; l < 5;l++) {
					
					b[i][j][k][l] = (rand() % 10) + 1;
					
					}}}}
	for(int i = 0; i < 5;i++) {
		for(int j = 0; j < 5;j++) {
			for(int k = 0; k < 5;k++) {
				for(int l = 0; l < 5;l++) {
					sum[i][j][k][l] = a[i][j][k][l] + b[i][j][k][l];
					printf("%d\t",sum[i][j][k][l]);
					}}}}*/

	
	/* Problem 12 */		

	/*char ch[] =  "Hello";
	int count = 0;
	
	printf("%s",ch);
	
	for(int i = 0; i >=0; i++){
	if(ch[i] == 0) break;
	count += 1;
	}
	printf("\nThe Length Of The String is : %d \n",count);*/

	
	/* Problem 13 */		

	/*int a = 0;
	char ch1[100],ch2[100];

	printf("Enter The First string : ");
	scanf("%[^\n]s",ch1);

	printf("\nEnter The Second string : ");
	scanf("\n%[^\n]s",ch2);

	for(int i = 0; ch1[i] != '\0'; i++){
	a++;
	
}

	for(int j = 0; ch2[j] != '\0'; j++){
	ch1[a] = ch2[j];
	a++;
	
	}

	 printf("\nThe Concatinated string is : %s",ch1);*/


	/* Problem 14 */		

	/*char ch1[100],ch2[100];
	printf("Enter The First string : ");
	scanf("%[^\n]s",ch1);

	for(int i = 0; ch1[i] != '\0'; i++){

	ch2[i] = ch1[i];

}

	printf("\nThe Copied string is : %s \n",ch2);*/


	/* Problem 15 */		

	/*char ch1[100],ch2[100];

	printf("Enter The First string : ");
	scanf("%[^\n]s",ch1);

	printf("\nEnter The Second string : ");
	scanf("\n%[^\n]s",ch2);


	if(strlen(ch1) == strlen(ch2)) {
	for(int i = 0; ch1[i] != '\0' && ch2[i] != '\0'; i++) {
   if(ch1[i] != ch2[i]) {
	printf("\nThe Given Two Strings Are Different\n");
	break;

   }
 
}

	printf("\nThe Given String are Same\n");

} 	else printf("\nThe Given Two Strings Are Different\n");*/


	/* Problem 16 */		

	/*char ch[100],ch1[100],ch2[100];
	int n,a = 0,flag = 0;
	printf("Enter The String : ");
	scanf("%[^\n]s",ch);

	n = strlen(ch) / 2;

	for(int i = 0; i < n; i++) {

	ch1[i] = ch[i];
}

	for(int i = (strlen(ch) - 1); i > n; i--) {

	ch2[a] = ch[i];
	a++;
}

	for(int i = 0; i < n; i++) {

	if(ch1[i] != ch2[i]) {

		printf("\nThe Given String is not a palindrome\n");
		flag = 1;
		break;
	}
}

	if(!flag) printf("The Given String is a Palindome\n");*/


	/* Problem 17 */		
	
	/*char ch[100],rev[100];
	int a = 0;

	printf("Enter The String : ");
	scanf("%[^\n]s",ch);

	for(int i = (strlen(ch) - 1); i >= 0; i--){

	rev[a] = ch[i];
	a++;

}

	printf("\nThe Reverse of the Given String is %s \n",rev);*/

	return 0;
}
	
