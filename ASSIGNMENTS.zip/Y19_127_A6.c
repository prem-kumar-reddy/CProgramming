#include<stdio.h>
int main()
{	/*Problem 1*/
	/*int n;	
	scanf("%d",&n);
	for(n>0;n%2!=0&n>0;)
	{  n=n-2;
	  printf("%d\n",n);}
	if(n>0&n%2==0)
	 { n=n-1;
	   for(n>0;n%2!=0&n>0;)
	   { printf("%d\n",n);
	     n=n-2;}
	}*/

	/*Problem 2*/
	/*char al;
	int n=97;
	for (n>0;al=n;n++)
	{if(n<=122)
	printf("%c",al);}*/

	/*Problem 3*/
	/*int n,sum;
	printf("Enter value of n=");
	scanf("%d",&n);
	sum=(n*(n+1)/2)-1-n;
	printf("The sum is %d\n",sum);*/
	
	/* Problem 4 */
	/*int n,sum;
	printf("Enter value of n=");
	scanf("%d",&n);
	if(n%2==0)
	{   sum=(n/2*(n/2+1))-n;
	    printf("The sum of all even numbers between 1 to n is %d\n",sum);
	}
	else
	{  n=n-1;
	   sum=(n/2*(n/2+1));
	   printf("The sum of all even numbers between 1 to n is %d\n",sum);
	}*/
	
	/* Problem 5 */
	/*int n,i,m;
	i=1;
	printf("enter which number multiplication table do you want\n");
	scanf("%d",&n);
	for(n>0;i<=10;i++)
	{  m=n*i;
	   printf("%d*%d=%d\n",n,i,m);}*/

	/* Problem 6*/
	/*int n,f,l;
	printf("Enter a number\n");
	scanf("%d",&n);
	l=n%10;
	for (n>0;n>9;)
	{n=n/10;
	 f=n;   }
	printf("The first digit is %d and last digit is %d\n",f,l);*/
	
	/* Problem 7*/
	/*int n,a=0,count=1,k;
	printf("Enter a number n=");
	scanf("%d",&n);
	k=n;
	for (n>0;n>9;count++)
	 n=n/10;
	 
	for (k>0;count>0;count--)
	  if(k>0)
	{ a=a*10;
	  a=a+k%10;
	  k=k/10;} 
	printf("Entered Number in reverse order is %d\n",a);*/
	
	/* Probelem 8*/
	/*int n,a=0,count=1,k,b;
	printf("Enter a number n=");
	scanf("%d",&n);
	k=n;
	b=n;
	for (n>0;n>9;count++)
	 n=n/10;
	 
	for (k>0;count>0;count--)
	  if(k>0)
	{ a=a*10;
	  a=a+k%10;
	  k=k/10;} 
	if(a==b)
	printf("Entered number is Palindrome number\n");
	else 
	printf("Entered number is not a palindrome number \n");*/
	
	/* Problem 9*/
	/*long num,b;
	int digit,rem,count=0;
	printf("Enter the Number: ");
	scanf("%ld",&num);
	b=num;
	  printf("Enter the digit to know frequency of that=");
	scanf("%d",&digit);
    while(num!=0)
    {
       rem=num%10;
       if(rem==digit)
         count++;
       num=num/10;
    }
	printf("The digit %d has frequency is %d in %ld\n",digit,count,b);*/

	/* Problem 10*/
	/*int n, num = 0;

    printf("Enter a number n=");
    scanf("%d", &n);

    while(n != 0)
    {
       num = (num * 10) + (n % 10);
       n /= 10;
    }

    while(num != 0)
    {
      switch(num % 10)
       {
          case 0: 
            printf("Zero ");
            break;
          case 1: 
            printf("One ");
            break;
          case 2: 
            printf("Two ");
            break;
          case 3: 
            printf("Three ");
            break;
          case 4: 
            printf("Four ");
            break;
          case 5: 
             printf("Five ");
             break;
          case 6: 
             printf("Six ");
               break;
           case 7: 
             printf("Seven ");
             break;
            case 8: 
             printf("Eight ");
             break;
           case 9: 
             printf("Nine ");
             break;
        }
         num = num / 10;
    }
	printf("\n");*/	

	/* Problem 11 */
	/*int base, exponent; 
	long int power = 1;
	int i;

	    printf("Enter base: ");
	    scanf("%d", &base);
	    printf("Enter exponent: ");
	    scanf("%d", &exponent);

	    for(i=1; i<=exponent; i++)
	    {
		power = power * base;
	    }

	    printf("%d ^ %d = %lld", base, exponent, power);*/

	/* Problem 12 */
	/*int n,a=1;
	printf("Enter a number to find it's factors n=");
	scanf("%d",&n);
	printf("The factors of entered number are ");
	for (n>0;a<=n;)
	 { if (n%a==0)
	    { printf("%d ",a);
	      }
	  a++;
	 }
	 printf("\n");  */ 
	
	/* Problem 13 */
	/*int n,k;
	printf("Enter a number n=");
	scanf("%d",&n);
	k=n-1;
	for (n>0;k>0;k--)
	   n=n*k;
	printf("Factorial of given number is %d\n",n);*/
     
	/* Problem 14 */
	/*int n,a,b;
	printf("Enter two numbers to get HCF of them n>a are ");
	scanf("%d%d",&n,&a);
	 for(n>0;a>0&n%a!=0;) 
       	    {b=a;
	     a=n%a;
	     n=b;}
	 printf("HCF of given two numbers is %d\n",a);*/

	/* Problem 15 */
	/*int n,a,b,c;
	printf("Enter two numbers to get LCM of them are ");
	scanf("%d%d",&n,&a);
	c=n*a;
	if(n>a)
	 {for(n>0;a>0&n%a!=0;) 
       	    {b=a;
	     a=n%a;
	     n=b;}
	   b=c/a;}  // Product of two numbers = LCM * HCF 
	else if(n<a)
	 {for(a>0;n>0&a%n!=0;) 
       	    {b=n;
	     n=a%n;
	     a=b;}
	  b=c/n;}  //Product of two numbers = LCM * HCF 
	
	 printf("LCM of given two numbers is %d\n",b);*/
	
	/* Problem 16 */
	/*int n,a,c;
	printf(" Enter a number n=");
	scanf("%d",&n);
	a=n-1;
	if(n==2)
	printf("Given %d is a prime number\n",n);
	for(n>0;a>1;a--)
	 {c=n%a;
	   if(c==0)
	    { printf("Given %d is a not prime number\n",n);
     	     break;}}
	 if (c!=0)
          printf("Given %d is a prime number\n",n);*/
	
	/* Problem 17 */
	/*int n,a,c;
	printf("Enter a number n=");
	scanf("%d",&n);
	if(n<=2)
	printf("There is no prime number <%d",n);
	n=n-1;
	while(n>1)
	{a=n-1;
	 for(n>0;a>1;a--)
	 {c=n%a;
	   if(c==0)
	    break;}
	 if (c!=0)
          printf("%d ",n);
	  n--;}
	printf("\n");*/
	
	/* Problem 18 */
	/*int n,a,c,sum=0,b;
	printf("Enter a number n=");
	scanf("%d",&n);
	b=n;
	if(n<=2)
	printf("Sum = 0");
	n=n-1;
	while(n>1)
	{a=n-1;
	 for(n>0;a>1;a--)
	 {c=n%a;
	   if(c==0)
	    break;}
	 if (c!=0)
	  sum = sum+n;
	  n--;}
	printf("Sum of prime numbers between 1 & %d is %d ",b,sum);
	printf("\n");*/

	/* Problem 19 */
	/*int n,a,b,c;
	printf("Enter a number to find it's prime factors n=");
	scanf("%d",&n);
	a=n-1;
	printf("Prime factors of entered number are ");
	for (n>0;a>1;a--)
	 { if (n%a==0)
	    {b=a-1;
	if(a==2)
	printf("%d ",a);
	else if(a!=2)
	{for(a>0;b>1;b--)
	 {c=a%b;
	   if(c==0)
	    break;}
	 if (c!=0)
          printf("%d ",a);} }
	  }
	printf("\n");*/

	/* Problem 22 */
	/*int i, n, term1 = 0, term2 = 1, nt;   //nt=next term
	printf("Enter the number of terms: ");
	scanf("%d", &n);
	printf("Fibonacci Series: ");
	for (i = 1; i <= n; ++i)
       {
         printf("%d ", term1);
         nt=term1+term2;
         term1=term2;
         term2=nt;
       }
	printf("\n");*/
	return 0;
}
