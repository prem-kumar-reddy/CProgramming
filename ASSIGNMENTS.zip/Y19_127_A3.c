#include<stdio.h>
#include<math.h>
int main()
{	
	/* Part-A */
	/* Problem 1 */

	int a,b,sum=0;
	printf("enter the 4 digit number\n");
	scanf("%d",&a);
	b=a%10;     /* gives the 4th digit of the number */
	sum=sum+b;
	a=a/10;
	b=a%10;		/* gives the 3rd digit of the number */		
	sum=sum+b;
	a=a/10;
	b=a%10;		/* gives the 2nd digit of the number */
	sum=sum+b;
	a=a/10;
	b=a%10;		/* gives the 1st digit of the number */
	sum=sum+b;
	printf("The sum of 4 digits of given number is %d\n",sum);

	/* Problem 2 */

	float  distance,fuel,mileage;
	printf(" Enter the distance travelled(in km) and fuel consumed(in ltr) \n");
	scanf("%f %f",&distance,&fuel);
	mileage=distance/fuel;
	printf("mileage of the vehicle is %f\n",mileage);

	/* Problem 3 */

	int m,d;
	printf("Enter no. of days \n");
	scanf("%d",&d);
	m=d/30;
	d=d%30;
	printf("No. of months is %d and days is %d\n",m,d);

	/* Problem 4 */
	
	int y;
	printf("Enter no. of days \n");
	scanf("%d",&d);
	y=d/365;
	m=d%365/30;
	d=d%365%30;
	printf("No. of years is %d months is %d and days is %d\n",y,m,d); 

	/* Problem 5 */

	int n,c,e,f,g,h,i,j;
	printf("Enter the amount\n");
	scanf("%d",&n);
	a=n/2000;
	b=n%2000/500;
	c=n%2000%500/200;
	d=n%2000%500%200/100;
	e=n%2000%500%200%100/50;
	f=n%2000%500%200%100%50/20;
	g=n%2000%500%200%100%50%20/10;
	h=n%2000%500%200%100%50%20%10/5;
	i=n%2000%500%200%100%50%20%10%5/2;
	j=n%2000%500%200%100%50%20%10%5%2;
	printf("no .of 	₹2000 notes is %d\n",a);
	printf("no .of  ₹500 notes is %d\n",b);
	printf("no .of  ₹200 notes is %d\n",c);
	printf("no .of  ₹100 notes is %d\n",d);
	printf("no .of  ₹50 notes is %d\n",e);
	printf("no .of  ₹20 notes is %d\n",f);
	printf("no .of  ₹10 notes is %d\n",g);
	printf("no .of   ₹5 coins is %d\n",h);
	printf("no .of   ₹2 coins is %d\n",i);
	printf("no .of   ₹1 coins is %d\n",j);

	/* Problem 6 */
	
	int s;
	printf("Enter no. of seconds\n");
	scanf("%d",&s);
	h=s/3600;
	m=s%3600/60;
	s=s%3600%60;
	printf("Time is %d Hour's %d Minutes %d Seconds\n",h,m,s);

	/* Problem 7 */

	float far,cel;
	printf("Enter the temperature in fahrenheit\n");
	scanf("%f",&far);
	cel=(far-32)/1.8;
	printf("The temperature in celsius is %f\n",cel);

	/* Part - B */
	/* Problem 8 */
	float x1,y1;
	printf("Enter the values of a,b,c\n");
	scanf("%d%d%d",&a,&b,&c);
	if  ((b*b-4*a*c)<0)
	     {
		printf("the roots are imaginary\n");
	     } 
	
	    if ((b*b-4*a*c)>=0)
	      {
		x1 = (-b+sqrt(b*b-4*a*c))/(2*a);
	        y1 = (-b-sqrt(b*b-4*a*c))/(2*a);
	        printf("The roots are %f and %f\n",x1,y1);
	     }

	/* Problem 9 */
	
	int a1,n1,sum1=0;
	float value,avg;
	printf("enter the no. of numbers to take average\n");
	scanf("%d",&n1);
	printf("Enter %d numbers\n",n1);
	
	for (a1=1; a1<=n1; a1++)
	    {	
		scanf("%f",&value);
		sum1=sum1+value;	 
	    }
	avg=sum1/n1;
	printf("The average of given numbers is %f\n",avg);
	
	return 0;
}
