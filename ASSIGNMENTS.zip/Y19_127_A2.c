#include <stdio.h>
#include <math.h>
#define n 100
int main()

{
	//Problem 1

	printf("Name:NESANURU PREM KUMAR REDDY\n");
	printf("Roll No. S20190010127\n");
	printf("Branch:Computer Science and Engineering\n");
	printf("Group-number:CP-4\n");
	

	//Problem 2

	int integer1, integer2;
	float c;
	printf("enter integer1 and integer2\n");
	scanf("%d%d",&integer1,&integer2);
	
	//addition
	c=integer1+integer2;
	printf("The sum of the given two numbers is %f\n",c);
	
	//subraction
	c=integer1-integer2;
	printf("The difference of given two numbers is %f\n",c);
	
	//multiplication
	c=integer1*integer2;
	printf("The product of given two numbers is %f\n",c);
	
	//division
	c=integer2/integer1;
	printf("The division of integer2 divided by integer1 %f\n",c);
	
	//modulus	
	c=integer1%integer2;
	printf("the modulus of two given numbers %f\n",c);

	//Problem 3

	//Calclulation	of Hypotenuse of a right angled triangle.
	
	int base,height;    //Base and Height of a Right Angled Triangle 
	float hypotenuse ;     // Hypotenuse of a Right Angled Triangle 
	printf("Enter the value of Base\n");
	scanf("%d",&base);
	printf("Enter the value of height\n");
	scanf("%d",&height);
	hypotenuse=sqrt(base*base+height*height);     // Formula for finding Hypotenuse of a Right Angled Triangle
	printf("The length of Hypotenuse%f\n",hypotenuse);

	//Problem 4
	//To find out addition of numbers that are in arthimetic progression
	int a,b,d,s;
	printf("Enter the first two integers a,b\n");
	scanf("%d%d",&a,&b);
	d=b-a;
	s=n*(2*a+(n-1)*d)/2;
	printf("sum of first 100 integers is %d\n",s);
	return 0;
}


